from tkinter import *
from tkinter import filedialog, messagebox
from tkinter.ttk import Combobox
from src.cryptography.Cryptography import Cryptography
from src.files.fileManager import *

OPTION_ENCRYPT = 1
OPTION_DECRYPT = 2
BACKGROUND_COLOR = "#242424"
FOREGROUND_COLOR = "white"
BUTTON_BACKGROUND_COLOR = "#1a438b"
BUTTON_BACKGROUND_COLOR_SELECTED = "#143266"
RADIOBUTTON_BACKGROUND = "#39399b"

FOLDER_NAME = ".encrypted"
EXTENSION = ".cpt"

appPath = getAbsPath(__file__)

# Frame
root = Tk()
root.title("Cryptography")
try: root.iconbitmap("assets/favicon.ico")
except: pass
root.config(bg=BACKGROUND_COLOR)
root.geometry("520x605")
root.resizable(True, True)

frame = Frame(root)
frame.pack(fill="both", expand="True")
frame.config(bg=BACKGROUND_COLOR)

headerFrame = Frame(frame, bg="black")
headerFrame.grid(row=0, column=0, sticky="nsew")

rbFrame = Frame(frame, bg=BACKGROUND_COLOR)
rbFrame.grid(row=1, column=0, sticky="nsew")

cryptTextFrame = Frame(frame, bg=BACKGROUND_COLOR)
cryptTextFrame.grid(row=2, column=0, sticky="nsew")

passwordFrame = Frame(frame, bg=BACKGROUND_COLOR)
passwordFrame.grid(row=3, column=0, sticky="nsew")

fileFrame = Frame(frame, bg=BACKGROUND_COLOR)
fileFrame.grid(row=4, column=0, sticky="nsew")

submitFrame = Frame(frame, bg=BACKGROUND_COLOR)
submitFrame.grid(row=5, column=0)

resultFrame = Frame(frame, bg=BACKGROUND_COLOR)
resultFrame.grid(row=6, column=0, sticky="nsew")

def onSubmitClicked():
    psw = password.get()
    text = getTextToProcess() 
    if fileNameList.current() > 0: text = readFile(FOLDER_NAME, getCurrentFileName())
    option = varOption.get()
    if len(text) > 0:
        if len(psw) > 0:
            hideWarning()
            cr = Cryptography(psw, 1, 3)
            result = cr.encrypt(text) if option == OPTION_ENCRYPT else cr.decrypt(text)
            if len(result) > 0:
                if option == OPTION_ENCRYPT: fileSaveButton.grid(row=0, column=3, padx=10, pady=(4, 14))
                fileSaveButton.config(state="normal", text="Save")
                setResultText(result)
            else: setResultText("No crypted text")
        else: showWarning("* password required")
    else: showWarning("* text required")

def onListElementSelected(event): 
    if fileNameList.current() > 0: 
        fileDeleteButton.grid(row=0, column=3, padx=10, pady=(4, 14))
        disableTextToProcess()
    else: 
        fileDeleteButton.grid_forget()
        enableTextToProcess()

def findFile():
    rbActionPerformed()
    path = filedialog.askopenfilename(
            title="Select", 
            initialdir="./", 
            filetypes=(("Cryptography", f"*{EXTENSION}"), ("Text", "*.txt"), ("Other text files", "*.*"))
        )
    fileContent = readFile(absPath=path)
    if len(fileContent) > 0: setTextToProcess(fileContent)

def deleteFile(): 
    if fileNameList.current() > 0:
        confirm = messagebox.askquestion("Delete", "Do you want to delete the file?")
        if confirm == 'yes':
            removed = removeFile(FOLDER_NAME, getCurrentFileName())
            if removed == True:
                showWarning("REMOVED")
            else: showWarning("ERROR")
            rbActionPerformed()
    else: showWarning("* no file selected")

def saveFile():
    if len(getResultText()) > 0:
        if len(fileName.get()) > 0:
            hideWarning()
            def createCPT(forceCreate=False): return createFile(FOLDER_NAME, fileName.get()+".cpt", getResultText(), forceCreate)
            createFolder(FOLDER_NAME)
            saved = createCPT()
            if saved == False:
                response = messagebox.askquestion("Overwrite", "Do you want to overwrite the file?")
                if response == 'yes': saved = createCPT(forceCreate=True)
            if saved == True: fileSaveButton.config(text="Saved!", state="disabled", fg="black")
            elif saved == False: fileSaveButton.config(text="Not saved", state="disabled", fg="black")
            else: (fileSaveButton.config(text="Error", state="disabled", fg="black"), setResultText(saved))
        else: showWarning("* file name required")
    else: (showWarning("* submit required"), fileSaveButton.grid_forget())

# RadioButtons
varOption = IntVar(value=OPTION_ENCRYPT)
def rbActionPerformed():
    enableTextToProcess()
    fileDeleteButton.grid_forget()
    if varOption.get() == OPTION_ENCRYPT:
        fileNameList.grid_forget()
        fileNameEntry.grid(row=0, column=1, padx=10, pady=(4, 14))
    else:
        fileNameEntry.grid_forget()
        fileSaveButton.grid_forget()
        fileNameList.grid(row=0, column=1, padx=10, pady=(4, 14))
        files = getFiles(FOLDER_NAME, EXTENSION)
        fileNameList['values'] = files
        fileNameList.set("")
def setOption(value): varOption.set(value)
rbE = Radiobutton(rbFrame, text="Encrypt", font=("Arial", 15, "bold"), variable=varOption, value=OPTION_ENCRYPT, fg=RADIOBUTTON_BACKGROUND, bg=BACKGROUND_COLOR)
rbE.grid(row=0, column=1, padx=(40,0))
rbE.bind("<ButtonPress-1>", lambda x: (rbE.config(state="disabled"), setOption(OPTION_ENCRYPT)))
rbE.bind("<ButtonRelease-1>", lambda x: (rbE.config(state="normal"), rbActionPerformed()))
rbD = Radiobutton(rbFrame, text="Decrypt", font=("Arial", 15, "bold"), variable=varOption, value=OPTION_DECRYPT, fg=RADIOBUTTON_BACKGROUND, bg=BACKGROUND_COLOR)
rbD.grid(row=0, column=2, padx=(40,0))
rbD.bind("<ButtonPress-1>", lambda x: (rbD.config(state="disabled"), setOption(OPTION_DECRYPT)))
rbD.bind("<ButtonRelease-1>", lambda x: (rbD.config(state="normal"), rbActionPerformed()))
Label(rbFrame, font=("Arial", 18), text="Text to process", fg=FOREGROUND_COLOR, bg=BACKGROUND_COLOR).grid(row=0, column=0, sticky="nsew", padx=10, pady=14)

# Header
Label(headerFrame, text="Cryptography", bg="#000000", fg=FOREGROUND_COLOR, font=("Comic Sans MS", 24)).grid(row=0, column=0, sticky="nsew", padx=10, pady=14)
Label(headerFrame, font=("Comic Sans MS", 1), text="", bg="#eeff01").grid(row=1, column=0, sticky="nsew")

# Text to process
textWidget = Text(cryptTextFrame, font=("Arial", 13), height=7)
textWidget.grid(row=0, column=0, sticky="nsew", padx=(10, 0))
scrollbar = Scrollbar(cryptTextFrame, command=textWidget.yview)
scrollbar.grid(row=0, column=1, sticky="nsew", padx=(0, 10))
textWidget.config(yscrollcommand=scrollbar.set)
def getTextToProcess(): return textWidget.get("1.0", "end").rstrip()
def setTextToProcess(text): (textWidget.delete("1.0", "end"), textWidget.insert("1.0", text))
def disableTextToProcess(): textWidget.config(state="disabled", fg="#9d9d9d", bg="#d7d7d7")
def enableTextToProcess(): textWidget.config(state="normal", fg="black", bg="white")

# Password
password = StringVar()
Label(passwordFrame, font=("Arial", 18), text="Password", fg=FOREGROUND_COLOR, bg=BACKGROUND_COLOR).grid(row=0, column=0, sticky="nsew", padx=10, pady=(14, 4))
Entry(passwordFrame, font=("Arial", 16), show="*", textvariable=password, width=12).grid(row=0, column=1, padx=10, pady=(14, 4))
Button(passwordFrame, font=("Arial", 10), text="Clean", bg="#ecd991", command=lambda: (rbActionPerformed(), setTextToProcess(""), clearPassword())).grid(row=0, column=2, padx=10, pady=(14, 4))

# Warning
warning = Label(passwordFrame, font=("Arial", 11, "bold"), text="* password required", fg="#d64a3a", bg=BACKGROUND_COLOR)
def showWarning(text="error"): (warning.grid(row=0, column=3, sticky="nsew", padx=2, pady=(14, 4)), warning.config(text=text))
def hideWarning(): warning.grid_forget()
def clearPassword(): password.set("")

# File name
fileName = StringVar()
Label(fileFrame, font=("Arial", 18), text="File name", fg=FOREGROUND_COLOR, bg=BACKGROUND_COLOR).grid(row=0, column=0, sticky="nsew", padx=10, pady=(4, 14))
fileNameEntry = Entry(fileFrame, font=("Arial", 16), width=12, textvariable=fileName)
fileNameEntry.grid(row=0, column=1, padx=10, pady=(4, 14))

# File list
fileNameList = Combobox(fileFrame, state="readonly", width=11, font=("Arial", 15))
fileNameList.bind("<<ComboboxSelected>>", onListElementSelected)
def getCurrentFileName(): return fileNameList.get() if fileNameList.get().endswith(EXTENSION) else fileNameList.get() + EXTENSION

# File find button
Button(fileFrame, font=("Arial", 10), text="Find", cursor="hand2", command=findFile).grid(row=0, column=2, padx=10, pady=(4, 14))

# File delete button
fileDeleteButton = Button(fileFrame, font=("Arial", 10, "bold"), command=deleteFile, text="Delete", cursor="hand1", bg="#d2665a")

# File save button
fileSaveButton = Button(fileFrame, font=("Arial", 10), command=saveFile, text="Save", cursor="hand2", bg="#4a9a08")

# Result
resultWidget = Text(resultFrame, font=("Arial", 13), height=7, state="disabled", fg=FOREGROUND_COLOR, bg=BACKGROUND_COLOR)
resultWidget.grid(row=0, column=0, sticky="nsew", padx=10, pady=(0, 14))
def setResultText(text): (resultWidget.config(state="normal"), resultWidget.delete("1.0", "end"), resultWidget.insert("1.0", text), resultWidget.config(state="disabled"))
def getResultText(): return resultWidget.get("1.0", "end").strip()

# Submit button
submitButton = Button(submitFrame, text="Submit", font=("Arial", 16), cursor="hand2", fg=FOREGROUND_COLOR, bg=BUTTON_BACKGROUND_COLOR, relief=RAISED)
submitButton.grid(row=0, column=0, sticky="nsew", pady=14)
submitButton.bind("<ButtonPress-1>", lambda e: (submitButton.config(state="disabled"), submitButton.config(fg=FOREGROUND_COLOR, bg=BUTTON_BACKGROUND_COLOR_SELECTED, relief=SUNKEN)))
submitButton.bind("<ButtonRelease-1>", lambda e: (submitButton.config(state="normal"), submitButton.config(fg=FOREGROUND_COLOR, bg=BUTTON_BACKGROUND_COLOR, relief=RAISED), onSubmitClicked()))

# Configurando la fila y columna que se adaptarán al tamaño del frame
frame.grid_columnconfigure(0, weight=1)
frame.grid_rowconfigure(6, weight=1)
headerFrame.grid_columnconfigure(0, weight=1)
cryptTextFrame.grid_columnconfigure(0, weight=1)
submitFrame.grid_columnconfigure(0, weight=1)
resultFrame.grid_columnconfigure(0, weight=1)
resultFrame.grid_rowconfigure(0, weight=1)

# Estableciendo el tamaño mínimo de la interfaz
root.update()
root.minsize(520, 605)
root.mainloop()