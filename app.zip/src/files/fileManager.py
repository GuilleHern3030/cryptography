import os

def getAbsPath(file): 
    try: return os.path.dirname(os.path.abspath(file))
    except: return file

def joinPath(folder1, folder2): 
    if len(folder1) == 0 or len(folder2) == 0: raise Exception("No file")
    try: return os.path.join(folder1, folder2)
    except: return folder1 + "/" + folder2

def createFile(folderName:str, fileName:str, text:str, forceRewrite:bool=False):
    try:
        filePath = joinPath(folderName, fileName)
        if not os.path.exists(filePath) or forceRewrite == True:
            file = open(filePath, "w")
            file.write(text)
            file.flush()
            file.close()
            return True # file created
        else: return False # file already exists
    except Exception as err: return err # file can not created

def createFolder(folderName):
    try:
        if not os.path.exists(folderName): 
            os.makedirs(folderName)
    except: pass

def getFiles(folderName, extension=None):
    files = ['']
    try:
        elements = os.listdir(folderName)
        for element in elements:
            if os.path.isfile(joinPath(folderName, element)):
                if extension == None or element.endswith(extension): 
                    files.append(element)
    except: pass
    return files

def removeFile(folderName, fileName):
    filePath = joinPath(folderName, fileName)
    try:
        if os.path.exists(filePath):
            os.remove(filePath)
            return True
    except: pass
    return False

def readFile(folderName="", fileName="", absPath=None):
    content = ""
    try:
        filePath = joinPath(folderName, fileName) if absPath == None else absPath
        file = open(filePath, "r")
        content = file.read()
        file.close()
    except: pass
    return content